from flask import Flask, request, jsonify
import subprocess
import json
import os

app = Flask(__name__)

def run_model1():
    # Run your python file (test.py) in the background
    subprocess.run(['python', 'test.py'])

    # Check if the extracted_info.json has been updated
    json_file = 'extracted_info.json'
    before = os.path.getmtime(json_file)

    # Perform some operations or checks here

    after = os.path.getmtime(json_file)
    if before != after:
        return "JSON file has been updated"
    else:
        return "JSON file has not been updated"

def run_model2():
    # Run your python file (footer_circle.py) in the background
    subprocess.run(['python', 'footer_circle.py'])

    # Check if the extraction_info.json has been updated
    json_file = 'extraction_data.json'
    before = os.path.getmtime(json_file)

    # Perform some operations or checks here

    after = os.path.getmtime(json_file)
    if before != after:
        return "JSON file has been updated"
    else:
        return "JSON file has not been updated"

@app.route('/main', methods=['POST'])
def main_route():
    # Call run_model1 and run_model2
    model1_output = run_model1()
    model2_output = run_model2()

    # Save the output data to output.json
    output_data = {
        "model1_output": model1_output,
        "model2_output": model2_output
    }

    with open('output.json', 'w') as f:
        json.dump(output_data, f)

    # Print the return statements to the terminal
    print("Model 1 output:", model1_output)
    print("Model 2 output:", model2_output)

    return jsonify(output_data)

if __name__ == '__main__':
    app.run(debug=False)
